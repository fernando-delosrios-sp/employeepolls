import { configureStore, combineReducers } from "@reduxjs/toolkit";
import { useDispatch } from "react-redux";
// import { authReducer } from "react-redux-firebase";

import { api } from "./api";
import { session } from "./session";

const reducer = combineReducers({
	[api.reducerPath]: api.reducer,
	[session.name]: session.reducer,
});

const devTools = process.env.NODE_ENV !== "production";

export const store = configureStore({
	reducer,
	// enhancers: [persistState('token', 'connectionList')],
	devTools,
	middleware: (getDefaultMiddleware) =>
		getDefaultMiddleware().concat(api.middleware),
});

type AppDispatch = typeof store.dispatch;

export type RootState = ReturnType<typeof store.getState>;
export const useAppDispatch: () => AppDispatch = useDispatch;
export default store;
