import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { Credentials, Session } from "../config/types";
import * as udacityApi from "../service/_DATA";

const name = "session";
const initialState = null as Session;

const login = createAsyncThunk(
	"session/login",
	async (credentials: Credentials) => {
		const response = await udacityApi._getUsers();
		const { id, name, avatarURL, password } =
			response[credentials.id.toLowerCase()];
		//...
		return { id, name, avatarURL: "hola" };
	}
);

export const session = createSlice({
	name: "session",
	initialState,
	reducers: {
		logout: (state) => (state = null),
	},
	extraReducers: (builder) => {
		builder.addCase(login.fulfilled, (state, action) => {
			return action.payload;
		});
	},
});

const logout = session.actions.logout;
export const actions = { login, logout };
